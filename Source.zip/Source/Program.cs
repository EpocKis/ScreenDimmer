using System;
using System.Collections.Generic;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace ScreenDimmer
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new ScreenDimmerContext());
        }
    }

    public class ScreenDimmerContext : ApplicationContext
    {
        private List<OverlayForm> overlays = new();
        private bool overlayVisible = false;
        private bool[] dimScreens;

        private NotifyIcon trayIcon;
        private ContextMenuStrip trayMenu;

        private Keys hotkey = Keys.D;
        private int modifiers = MOD_CONTROL | MOD_ALT;

        private HotkeyWindow hotkeyWindow;

        private const int WM_HOTKEY = 0x312;
        private const int MOD_ALT = 0x1;
        private const int MOD_CONTROL = 0x2;
        private const int MOD_SHIFT = 0x4;

        [DllImport("user32.dll")]
        private static extern bool RegisterHotKey(IntPtr hWnd, int id, int fsModifiers, int vk);

        [DllImport("user32.dll")]
        private static extern bool UnregisterHotKey(IntPtr hWnd, int id);

        public ScreenDimmerContext()
        {
            // Tray icon
            trayIcon = new NotifyIcon
            {
                Icon = new Icon("ScreenDimmer.ico"), // <-- icon file in same folder as .exe
                Text = "ScreenDimmer",
                Visible = true
            };

            // Tray menu
            trayMenu = new ContextMenuStrip();
            trayMenu.Items.Add("Select Monitors", null, SelectMonitors);
            trayMenu.Items.Add("Change Hotkey", null, ChangeHotkey);
            trayMenu.Items.Add("Exit", null, ExitApp);
            trayIcon.ContextMenuStrip = trayMenu;

            // Multi-monitor overlays
            int screenCount = Screen.AllScreens.Length;
            dimScreens = new bool[screenCount];
            for (int i = 0; i < screenCount; i++)
            {
                dimScreens[i] = i == 1; // default second monitor
                overlays.Add(new OverlayForm(Screen.AllScreens[i].Bounds));
            }

            // Hotkey window
            hotkeyWindow = new HotkeyWindow();
            hotkeyWindow.HotkeyPressed += ToggleOverlays;
            RegisterHotKey(hotkeyWindow.Handle, 1, modifiers, (int)hotkey);
        }

        private void ToggleOverlays()
        {
            overlayVisible = !overlayVisible;
            for (int i = 0; i < overlays.Count; i++)
            {
                if (dimScreens[i])
                {
                    if (overlayVisible)
                        overlays[i].Show();
                    else
                        overlays[i].Hide();
                }
                else
                {
                    overlays[i].Hide();
                }
            }
        }

        private void SelectMonitors(object? sender, EventArgs? e)
        {
            Form form = new()
            {
                Text = "Select Monitors to Dim",
                Width = 300,
                Height = 50 + Screen.AllScreens.Length * 30,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                StartPosition = FormStartPosition.CenterScreen
            };

            CheckBox[] checkboxes = new CheckBox[Screen.AllScreens.Length];
            for (int i = 0; i < Screen.AllScreens.Length; i++)
            {
                checkboxes[i] = new CheckBox
                {
                    Text = $"Screen {i + 1}: {Screen.AllScreens[i].Bounds.Width}x{Screen.AllScreens[i].Bounds.Height}",
                    Checked = dimScreens[i],
                    Dock = DockStyle.Top
                };
                form.Controls.Add(checkboxes[i]);
            }

            Button okBtn = new() { Text = "OK", Dock = DockStyle.Bottom };
            okBtn.Click += (s, ev) =>
            {
                for (int i = 0; i < Screen.AllScreens.Length; i++)
                {
                    dimScreens[i] = checkboxes[i].Checked;
                    if (!dimScreens[i] && overlays[i].Visible)
                        overlays[i].Hide();
                }
                form.Close();
                form.Dispose();
            };
            form.Controls.Add(okBtn);

            form.ShowDialog();
        }

        private void ChangeHotkey(object? sender, EventArgs? e)
        {
            using HotkeyForm dialog = new(hotkey, modifiers);
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                UnregisterHotKey(hotkeyWindow.Handle, 1);
                hotkey = dialog.SelectedKey;
                modifiers = dialog.SelectedModifiers;
                RegisterHotKey(hotkeyWindow.Handle, 1, modifiers, (int)hotkey);
            }
        }

        private void ExitApp(object? sender, EventArgs? e)
        {
            trayIcon.Visible = false;
            foreach (var o in overlays) o.Close();
            Application.Exit();
        }
    }

    public class OverlayForm : Form
    {
        public OverlayForm(Rectangle bounds)
        {
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.Manual;
            Bounds = bounds;
            BackColor = Color.Black;
            TopMost = true;
            ShowInTaskbar = false;
            Opacity = 1.0;
        }

        protected override CreateParams CreateParams
        {
            get
            {
                var cp = base.CreateParams;
                cp.ExStyle |= 0x80; // WS_EX_TOOLWINDOW hides from Alt+Tab
                return cp;
            }
        }
    }

    public class HotkeyForm : Form
    {
        public Keys SelectedKey { get; private set; }
        public int SelectedModifiers { get; private set; }

        public HotkeyForm(Keys currentKey, int currentModifiers)
        {
            SelectedKey = currentKey;
            SelectedModifiers = currentModifiers;

            Text = "Select Hotkey";
            Width = 400;
            Height = 150;

            Label label = new()
            {
                Text = "Press your desired hotkey combination and click OK",
                Dock = DockStyle.Top
            };
            Controls.Add(label);

            TextBox textBox = new() { Dock = DockStyle.Top };
            textBox.KeyDown += TextBox_KeyDown;
            Controls.Add(textBox);

            Button okBtn = new() { Text = "OK", Dock = DockStyle.Bottom };
            okBtn.Click += (s, e) => { DialogResult = DialogResult.OK; Close(); };
            Controls.Add(okBtn);
        }

        private void TextBox_KeyDown(object? sender, KeyEventArgs e)
        {
            SelectedKey = e.KeyCode;
            SelectedModifiers = 0;
            if (e.Control) SelectedModifiers |= 0x2;
            if (e.Alt) SelectedModifiers |= 0x1;
            if (e.Shift) SelectedModifiers |= 0x4;

            if (sender is TextBox textBox)
                textBox.Text = $"{(e.Control ? "Ctrl+" : "")}{(e.Alt ? "Alt+" : "")}{(e.Shift ? "Shift+" : "")}{e.KeyCode}";

            e.SuppressKeyPress = true;
        }
    }

    public class HotkeyWindow : NativeWindow
    {
        public event Action? HotkeyPressed;

        public HotkeyWindow()
        {
            CreateHandle(new CreateParams());
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == 0x312) // WM_HOTKEY
                HotkeyPressed?.Invoke();
            base.WndProc(ref m);
        }
    }
}